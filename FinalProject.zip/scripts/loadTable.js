// loadTable.js
// table id = signers
$(document).ready( function () {
    $('#signers').DataTable();
} );