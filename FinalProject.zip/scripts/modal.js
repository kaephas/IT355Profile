// modal.js
// modal id = exampleModalCenter
$(document).ready(function() {
    $("#exampleModalCenter").modal("show");
});